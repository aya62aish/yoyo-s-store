<aside class="sidebar-left border-right bg-white shadow" id="leftSidebar" data-simplebar>
    <a href="#" class="btn collapseSidebar toggle-btn d-lg-none text-muted ml-2 mt-3" data-toggle="toggle">
        <i class="fe fe-x"><span class="sr-only"></span></i>
    </a>
    <nav class="vertnav navbar navbar-light">
        <!-- nav bar -->
        <div class="w-100 mb-4 d-flex">
            <a class="navbar-brand mx-auto mt-2 flex-fill text-center" href="<?php echo e(route('admin.index')); ?>">
                <svg version="1.1" id="logo" class="navbar-brand-img brand-sm" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 120 120"
                    xml:space="preserve">
                    <g>
                        <polygon class="st0" points="78,105 15,105 24,87 87,87 	" />
                        <polygon class="st0" points="96,69 33,69 42,51 105,51 	" />
                        <polygon class="st0" points="78,33 15,33 24,15 87,15 	" />
                    </g>
                </svg>
            </a>
        </div>

        
        <ul class="navbar-nav flex-fill w-100 mb-2">
            <li class="nav-item w-100">
                <a class="nav-link" href="<?php echo e(route('admin.index')); ?>">
                    <i class="fe fe-home fe-16"></i>
                    <span class="ml-3 item-text"><?php echo e(__('keywords.home')); ?></span>
                </a>
            </li>
        </ul>

        <p class="text-muted nav-heading mt-4 mb-1">
            <span><?php echo e(__('keywords.components')); ?></span>
        </p>
        <ul class="navbar-nav flex-fill w-100 mb-2">
            
            <?php if (isset($component)) { $__componentOriginal162cb75c0411d2646b58e235cde3cb28 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal162cb75c0411d2646b58e235cde3cb28 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-tab','data' => ['href' => ''.e(route('admin.sections')).'','icon' => 'fe-codesandbox','name' => ''.e(__('keywords.sections')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-tab'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.sections')).'','icon' => 'fe-codesandbox','name' => ''.e(__('keywords.sections')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal162cb75c0411d2646b58e235cde3cb28)): ?>
<?php $attributes = $__attributesOriginal162cb75c0411d2646b58e235cde3cb28; ?>
<?php unset($__attributesOriginal162cb75c0411d2646b58e235cde3cb28); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal162cb75c0411d2646b58e235cde3cb28)): ?>
<?php $component = $__componentOriginal162cb75c0411d2646b58e235cde3cb28; ?>
<?php unset($__componentOriginal162cb75c0411d2646b58e235cde3cb28); ?>
<?php endif; ?>

            
            <?php if (isset($component)) { $__componentOriginal162cb75c0411d2646b58e235cde3cb28 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal162cb75c0411d2646b58e235cde3cb28 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-tab','data' => ['href' => ''.e(route('admin.categories')).'','icon' => 'fe-folder','name' => ''.e(__('keywords.categories')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-tab'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.categories')).'','icon' => 'fe-folder','name' => ''.e(__('keywords.categories')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal162cb75c0411d2646b58e235cde3cb28)): ?>
<?php $attributes = $__attributesOriginal162cb75c0411d2646b58e235cde3cb28; ?>
<?php unset($__attributesOriginal162cb75c0411d2646b58e235cde3cb28); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal162cb75c0411d2646b58e235cde3cb28)): ?>
<?php $component = $__componentOriginal162cb75c0411d2646b58e235cde3cb28; ?>
<?php unset($__componentOriginal162cb75c0411d2646b58e235cde3cb28); ?>
<?php endif; ?>

            
            <?php if (isset($component)) { $__componentOriginal162cb75c0411d2646b58e235cde3cb28 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal162cb75c0411d2646b58e235cde3cb28 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-tab','data' => ['href' => ''.e(route('admin.members')).'','icon' => 'fe-users','name' => ''.e(__('keywords.members')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-tab'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.members')).'','icon' => 'fe-users','name' => ''.e(__('keywords.members')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal162cb75c0411d2646b58e235cde3cb28)): ?>
<?php $attributes = $__attributesOriginal162cb75c0411d2646b58e235cde3cb28; ?>
<?php unset($__attributesOriginal162cb75c0411d2646b58e235cde3cb28); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal162cb75c0411d2646b58e235cde3cb28)): ?>
<?php $component = $__componentOriginal162cb75c0411d2646b58e235cde3cb28; ?>
<?php unset($__componentOriginal162cb75c0411d2646b58e235cde3cb28); ?>
<?php endif; ?>

            
            <?php if (isset($component)) { $__componentOriginal162cb75c0411d2646b58e235cde3cb28 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal162cb75c0411d2646b58e235cde3cb28 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-tab','data' => ['href' => ''.e(route('admin.ads')).'','icon' => 'bi bi-megaphone','name' => ''.e(__('keywords.ads')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-tab'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.ads')).'','icon' => 'bi bi-megaphone','name' => ''.e(__('keywords.ads')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal162cb75c0411d2646b58e235cde3cb28)): ?>
<?php $attributes = $__attributesOriginal162cb75c0411d2646b58e235cde3cb28; ?>
<?php unset($__attributesOriginal162cb75c0411d2646b58e235cde3cb28); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal162cb75c0411d2646b58e235cde3cb28)): ?>
<?php $component = $__componentOriginal162cb75c0411d2646b58e235cde3cb28; ?>
<?php unset($__componentOriginal162cb75c0411d2646b58e235cde3cb28); ?>
<?php endif; ?>



            
            <?php if (isset($component)) { $__componentOriginal162cb75c0411d2646b58e235cde3cb28 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal162cb75c0411d2646b58e235cde3cb28 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-tab','data' => ['href' => ''.e(route('admin.messages')).'','icon' => 'fe-message-square','name' => ''.e(__('keywords.messages')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-tab'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.messages')).'','icon' => 'fe-message-square','name' => ''.e(__('keywords.messages')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal162cb75c0411d2646b58e235cde3cb28)): ?>
<?php $attributes = $__attributesOriginal162cb75c0411d2646b58e235cde3cb28; ?>
<?php unset($__attributesOriginal162cb75c0411d2646b58e235cde3cb28); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal162cb75c0411d2646b58e235cde3cb28)): ?>
<?php $component = $__componentOriginal162cb75c0411d2646b58e235cde3cb28; ?>
<?php unset($__componentOriginal162cb75c0411d2646b58e235cde3cb28); ?>
<?php endif; ?>

            
            <?php if (isset($component)) { $__componentOriginal162cb75c0411d2646b58e235cde3cb28 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal162cb75c0411d2646b58e235cde3cb28 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-tab','data' => ['href' => ''.e(route('admin.ratings')).'','icon' => 'fe-message-circle','name' => ''.e(__('keywords.rating')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-tab'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.ratings')).'','icon' => 'fe-message-circle','name' => ''.e(__('keywords.rating')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal162cb75c0411d2646b58e235cde3cb28)): ?>
<?php $attributes = $__attributesOriginal162cb75c0411d2646b58e235cde3cb28; ?>
<?php unset($__attributesOriginal162cb75c0411d2646b58e235cde3cb28); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal162cb75c0411d2646b58e235cde3cb28)): ?>
<?php $component = $__componentOriginal162cb75c0411d2646b58e235cde3cb28; ?>
<?php unset($__componentOriginal162cb75c0411d2646b58e235cde3cb28); ?>
<?php endif; ?>
        </ul>

    </nav>
</aside>
<?php /**PATH C:\xampp\htdocs\talabat\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>