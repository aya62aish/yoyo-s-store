<?php $__env->startSection('title', __('keywords.show')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card shadow-lg mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0"><?php echo e(__('keywords.rating')); ?></h5>
                    </div>
                    <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card-body">
                            <!-- Display each attribute in a separate row -->
                            <div class="row mb-3">
                                <div class="col-md-3 font-weight-bold"><?php echo e(__('keywords.rating_number')); ?></div>
                                <div class="col-md-9"><?php echo e($rating->rating); ?></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-3 font-weight-bold"><?php echo e(__('keywords.rating_review')); ?></div>
                                <div class="col-md-9"><?php echo e($rating->review); ?></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\talabat\resources\views/admin/rating/index.blade.php ENDPATH**/ ?>