<?php $__env->startSection('title', __('keywords.show')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card shadow-lg mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0"><?php echo e(__('keywords.ad_details')); ?></h5>
                    </div>
                    <div class="card-body">
                        <!-- Display each attribute in a separate row -->
                        <div class="row mb-3">
                            <div class="col-md-3 font-weight-bold"><?php echo e(__('keywords.title')); ?></div>
                            <div class="col-md-9"><?php echo e($section); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-3 font-weight-bold"><?php echo e(__('keywords.category_name')); ?></div>
                            <div class="col-md-9"><?php echo e($category); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-3 font-weight-bold"><?php echo e(__('keywords.member_name')); ?></div>
                            <div class="col-md-9"><?php echo e($member); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-3 font-weight-bold"><?php echo e(__('keywords.ad_title')); ?></div>
                            <div class="col-md-9"><?php echo e($ad->title); ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-3 font-weight-bold"><?php echo e(__('keywords.ad_image')); ?></div>
                            <div class="col-md-9">
                                <?php if($ad->image): ?>
                                    <img src="<?php echo e(asset($ad->image)); ?>" alt="<?php echo e($ad->title); ?>" class="img-fluid rounded shadow" style="max-width: 300px; height: auto;">
                                <?php else: ?>
                                    <p class="text-muted"><?php echo e(__('keywords.no_image_available')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-3 font-weight-bold"><?php echo e(__('keywords.ad_description')); ?></div>
                            <div class="col-md-9"><?php echo e($ad->description); ?></div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-3 font-weight-bold"><?php echo e(__('keywords.ad_status')); ?></div>
                            <div class="col-md-9"><?php echo e($ad->status); ?></div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\talabat\resources\views/admin/ads/show.blade.php ENDPATH**/ ?>