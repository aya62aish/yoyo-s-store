<li class="nav-item w-100">
    <a class="nav-link" href="<?php echo e($href); ?>">
        <i class="fe <?php echo e($icon); ?> fe-16"></i>
        <span class="ml-3 item-text"><?php echo e($name); ?></span>
    </a>
</li>
<?php /**PATH C:\xampp\htdocs\talabat\resources\views/components/sidebar-tab.blade.php ENDPATH**/ ?>