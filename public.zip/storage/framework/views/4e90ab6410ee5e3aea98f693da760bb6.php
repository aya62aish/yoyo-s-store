<?php $__env->startSection('title', __('keywords.show')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card shadow-lg mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0"><?php echo e(__('keywords.messages')); ?></h5>
                    </div>
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card-body">
                            <!-- Display each attribute in a separate row -->
                            <div class="row mb-3">
                                <div class="col-md-3 font-weight-bold"><?php echo e(__('keywords.message_name')); ?></div>
                                <div class="col-md-9"><?php echo e($message->name); ?></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-3 font-weight-bold"><?php echo e(__('keywords.message_message')); ?></div>
                                <div class="col-md-9"><?php echo e($message->message); ?></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\talabat\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>