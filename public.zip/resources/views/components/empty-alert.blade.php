<tr>
    <td colspan="100%">
        <div class="alert alert-danger">{{ __('keywords.no_records_found') }}</div>
    </td>
</tr>
