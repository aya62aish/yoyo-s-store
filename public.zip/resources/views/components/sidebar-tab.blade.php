<li class="nav-item w-100">
    <a class="nav-link" href="{{ $href }}">
        <i class="fe {{ $icon }} fe-16"></i>
        <span class="ml-3 item-text">{{ $name }}</span>
    </a>
</li>
