@extends('admin.master')

@section('title', __('keywords.add_new_service'))

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <h2 class="h5 page-title">{{ __('keywords.add_new_section') }}</h2>

                <div class="card shadow">
                    <div class="card-body">
                        <form action="{{route('admin.sections.store')}}" method="post" enctype="multipart/form-data">
                            @csrf

                            <div class="row">
                                <div class="col-md-6">
                                    <x-form-label field="title"></x-form-label>
                                    <input type="text" name="title" class="form-control"
                                           placeholder="{{ __('keywords.title') }}">
                                    <x-validation-error field="title"></x-validation-error>
                                </div>
                            </div>

                            <x-submit-button></x-submit-button>
                        </form>
                    </div>
                </div>

                <!-- Display all sections with Show and Delete options -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('keywords.all_sections') }}</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>{{ __('keywords.title') }}</th>
                                <th class="d-flex justify-content-end" >{{ __('keywords.actions') }}</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($sections as $section)
                                <tr>
                                    <td>{{ $section->name }}</td>
                                    <td class="d-flex justify-content-end">
                                        <!-- Show Section Button -->
                                        <a href="{{route('admin.sections.show',$section->id)}}" class="btn btn-info btn-sm me-2">
                                            {{ __('keywords.show') }}
                                        </a>

                                        <!-- Delete Section Button -->
                                        <form action="{{route('admin.sections.destroy',$section->id)}}" method="POST" style="display:inline;">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger btn-sm"
                                                    style="margin-left: 10px;"
                                                    onclick="return confirm('{{ __('keywords.confirm_delete') }}')">
                                                {{ __('keywords.delete') }}
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- End of all sections list -->
            </div>
        </div>
    </div>
@endsection
