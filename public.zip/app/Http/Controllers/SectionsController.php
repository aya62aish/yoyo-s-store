<?php

namespace App\Http\Controllers;

use App\Models\category;
use App\Models\section;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SectionsController extends Controller
{
    public function index(){
        $sections = section::all();
        return view('admin.sections.create',compact('sections'));
    }
    public function store(Request $request){
        $name = $request->input('title');
        section::create(
            ['name' => $name],
        );
        return redirect()->route('admin.sections');
    }
    public function show($id)
    {
        $section = Section::findOrFail($id);
        $categories = Category::where('section_id',$id)->get();
        return view('admin.sections.show', compact('section','categories'));
    }
    public function destroy($id)
    {
        $section = section::where('id', $id)->delete();
        return redirect()->route('admin.sections')->with('suc cess', __('keywords.section_deleted'));
    }
}
