<?php

return [
    'dashboard' => 'لوحة التحكم',
    'index'     => 'الصفحة الرئيسية',
    'welcome'   => 'مرحبا',

    // Login page translations
    'sign_in'  => 'تسجيل الدخول',
    'email'    => 'البريد الالكترونى',
    'password' => 'كلمة السر',
    'remember' => 'تذكرنى',
    'login'    => 'تسجيل الدخول',
    'logout'   => 'تسجيل الخروج',
];
